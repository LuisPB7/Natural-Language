################   Testes do Transdutor Romanos ###############

python scripts/word2fst.py  99 > testes/transdutorRomanos/99_r.txt
python scripts/word2fst.py  28 > testes/transdutorRomanos/28_r.txt
python scripts/word2fst.py  100 > testes/transdutorRomanos/100_r.txt
python scripts/word2fst.py  1 > testes/transdutorRomanos/1_r.txt
python scripts/word2fst.py  8 > testes/transdutorRomanos/8_r.txt
python scripts/word2fst.py  45 > testes/transdutorRomanos/45_r.txt
python scripts/word2fst.py  72 > testes/transdutorRomanos/72_r.txt


################   Testes do Transdutor 1 #####################

python scripts/word2fst.py  99_ > testes/transdutor1/99_t1.txt
python scripts/word2fst.py  99_aa_ > testes/transdutor1/99_aa_t1.txt
python scripts/word2fst.py  batata_28_ > testes/transdutor1/batata_28_t1.txt
python scripts/word2fst.py  ir_tambem_ > testes/transdutor1/ir_tambem_t1.txt
python scripts/word2fst.py  _ola_ > testes/transdutor1/_ola_t1.txt
python scripts/word2fst.py  batatada_com_alguem_21_ > testes/transdutor1/batatada_com_alguem_21_t1.txt
python scripts/word2fst.py  23_teste_35_vai_passar_ > testes/transdutor1/23_teste_35_vai_passar_t1.txt
python scripts/word2fst.py  13_sexta_feira_88_ > testes/transdutor1/13_sexta_feira_88_t1.txt

################   Testes do inverso do Transdutor 1 ##########

python scripts/word2fst.py  XCIX_ > testes/transdutor1Inv/XCIX__invt1.txt
python scripts/word2fst.py  XCIX_aa_ > testes/transdutor1Inv/XCIX_aa_invt1.txt
python scripts/word2fst.py  batata_XXVIII_ > testes/transdutor1Inv/batata_XXVIII_invt1.txt
python scripts/word2fst.py  ir_tambem_ > testes/transdutor1Inv/ir_tambem_invt1.txt
python scripts/word2fst.py  _ola_ > testes/transdutor1Inv/_ola_invt1.txt
python scripts/word2fst.py  batatada_com_alguem_XXI_ > testes/transdutor1Inv/batatada_com_alguem_XXI_invt1.txt
python scripts/word2fst.py  XXIII_teste_XXXV_vai_passar_ > testes/transdutor1Inv/XXIII_teste_XXXV_vai_passar_invt1.txt
python scripts/word2fst.py  XIII_sexta_feira_LXXXVIII_ > testes/transdutor1Inv/XIII_sexta_feira_LXXXVIII_invt1.txt

################   Testes do Transdutor 2 #####################

python scripts/word2fst.py  XCIX_ > testes/transdutor2/XCIX_t2.txt
python scripts/word2fst.py  XCIX_aa_ > testes/transdutor2/XCIX_aa_t2.txt
python scripts/word2fst.py  batata_XXVIII_ > testes/transdutor2/batata_XXVIII_t2.txt
python scripts/word2fst.py  ir_tambem_ > testes/transdutor2/ir_tambem_t2.txt
python scripts/word2fst.py  _ir_tambem_de_mota_ > testes/transdutor2/_ir_tambem_de_mota_t2.txt
python scripts/word2fst.py  ir_de_XL_mota_ > testes/transdutor2/ir_de_XL_mota_t2.txt

################   Testes do inverso do Transdutor 2 ##########

python scripts/word2fst.py  3513_ > testes/transdutor2Inv/3513_invt2.txt
python scripts/word2fst.py  3513_aa_ > testes/transdutor2Inv/3513_aa_invt2.txt
python scripts/word2fst.py  batata_332111_ > testes/transdutor2Inv/batata_332111_invt2.txt
python scripts/word2fst.py  ir_tambem_ > testes/transdutor2Inv/ir_tambem_invt2.txt
python scripts/word2fst.py  _ir_tambem_de_mota_ > testes/transdutor2Inv/_ir_tambem_de_mota_invt2.txt
python scripts/word2fst.py  ir_de_34_mota_ > testes/transdutor2Inv/ir_de_34_mota_invt2.txt

################   Testes do Transdutor 3 #####################

python scripts/word2fst.py  3513_ > testes/transdutor3/3513_t3.txt
python scripts/word2fst.py  3513_aa_ > testes/transdutor3/3513_aa_t3.txt
python scripts/word2fst.py  batata_332111_ > testes/transdutor3/batata_332111_t3.txt
python scripts/word2fst.py  ir_tambem_ > testes/transdutor3/ir_tambem_t3.txt

################   Testes do inverso do Transdutor 3 ##########

python scripts/word2fst.py  3513_ > testes/transdutor3Inv/3513_invt3.txt
python scripts/word2fst.py  3513_XX_ > testes/transdutor3Inv/3513_XX_invt3.txt
python scripts/word2fst.py  bXtXtX_332111_ > testes/transdutor3Inv/bXtXtX_332111_invt3.txt
python scripts/word2fst.py  Vr_tX79m_ > testes/transdutor3Inv/Vr_tX79m_invt3.txt

################   Testes do Codificador ######################

python scripts/word2fst.py  99_ > testes/codificador/99_c.txt
python scripts/word2fst.py  99_aa_ > testes/codificador/99_aa_c.txt
python scripts/word2fst.py  batata_28_ > testes/codificador/batata_28_c.txt
python scripts/word2fst.py  ir_tambem_ > testes/codificador/ir_tambem_c.txt

################   Testes do Descodificador ###################

python scripts/word2fst.py  3513_ > testes/descodificador/3513_d.txt
python scripts/word2fst.py  3513_XX_ > testes/descodificador/3513_XX_d.txt
python scripts/word2fst.py  bXtXtX_332111_ > testes/descodificador/bXtXtX_332111_d.txt
python scripts/word2fst.py  Vr_tX79m_ > testes/descodificador/ir_tambem_d.txt
