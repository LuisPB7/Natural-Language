rm *.fst
rm *.pdf
