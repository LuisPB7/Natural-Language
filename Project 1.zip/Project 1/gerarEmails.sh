########################################################
### Gerar transdutores para emails a descodificar ######
########################################################

# emails a descodificar:

python scripts/word2fst.py Xs_21_pm_32111_d9_d9z97r0_3332111_3412_312_n_13_32111_31_0_ > emails/descodificar1.txt

python scripts/word2fst.py 3332111_3412_321_n_13_2111_321_0_3311_d9_jXn9Vr0_p9lXs_312_h_ > emails/descodificar2.txt

python scripts/word2fst.py bLblL0t9cX_d0_pXlXcL0_d9_m0ns9rrXt9_nX_9stXnt9_X_9sq89rdX_n0_dLX_312_d9_n0v97r0_p9lXs_3_33111_d9_mXL0_ > emails/descodificar3.txt

# email a codificar:

python scripts/word2fst.py biblioteca_do_palacio_de_monserrate_na_estante_a_esquerda_no_dia_14_de_novembro_pelas_10_23_de_maio_ > emails/codificar1.txt
