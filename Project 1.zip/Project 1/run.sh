#!/bin/bash

############################################################################
################### Construção dos Transdutores ############################
############################################################################

################### Construção do Transdutor de Números Romanos ############

################### Construção do Transdutor Romanos #######################
fstcompile --isymbols=syms.txt --osymbols=syms.txt  transdutorArabicos.txt | fstarcsort > transdutorArabicos.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutorArabicos.fst | dot -Tpdf  > transdutorArabicos.pdf
fstinvert	transdutorArabicos.fst > transdutorRomanos.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutorRomanos.fst | dot -Tpdf  > transdutorRomanos.pdf

################### Construção do Transdutor 1 #############################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  transdutorIgnoraLetras.txt | fstarcsort > transdutorIgnoraLetras.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutorIgnoraLetras.fst | dot -Tpdf  > transdutorIgnoraLetras.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  transdutorUnderscores.txt | fstarcsort > transdutorUnderscores.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutorUnderscores.fst | dot -Tpdf  > transdutorUnderscores.pdf

fstunion transdutorIgnoraLetras.fst transdutorRomanos.fst > transdutorNumerosOuLetras.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutorNumerosOuLetras.fst | dot -Tpdf  > transdutorNumerosOuLetras.pdf

fstconcat transdutorNumerosOuLetras.fst transdutorUnderscores.fst > transdutor1Iteracao.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutor1Iteracao.fst | dot -Tpdf  > transdutor1Iteracao.pdf

fstclosure	transdutor1Iteracao.fst > transdutor1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutor1.fst | dot -Tpdf  > transdutor1.pdf

################### Construção do Transdutor 2 #############################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  transdutor2.txt | fstarcsort > transdutor2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutor2.fst | dot -Tpdf  > transdutor2.pdf

################### Construção do Transdutor 3 #############################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  transdutor3.txt | fstarcsort > transdutor3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutor3.fst | dot -Tpdf  > transdutor3.pdf

################### Construção do Codificador  #############################

fstcompose transdutor1.fst transdutor2.fst > transdutor12.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait transdutor12.fst | dot -Tpdf > transdutor12.pdf

fstcompose transdutor12.fst transdutor3.fst > codificador.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait codificador.fst | dot -Tpdf > codificador.pdf

################### Construção do Inverso 1  ##########################

fstinvert	transdutor1.fst > transdutorInv1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutorInv1.fst | dot -Tpdf  > transdutorInv1.pdf


################### Construção do Inverso 2  ##########################

fstinvert	transdutor2.fst > transdutorInv2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutorInv2.fst | dot -Tpdf  > transdutorInv2.pdf

################### Construção do Inverso 3  ##########################

fstinvert	transdutor3.fst > transdutorInv3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait transdutorInv3.fst | dot -Tpdf  > transdutorInv3.pdf

################### Construção do Descodificador  ##########################

fstinvert	codificador.fst > descodificador.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait descodificador.fst | dot -Tpdf  > descodificador.pdf

############################################################################
################### 		Compila Testes      ############################
############################################################################

################   Testes do Transdutor Romanos ###############

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutorRomanos/99_r.txt | fstarcsort > testes/transdutorRomanos/99_r.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutorRomanos/99_r.fst | dot -Tpdf  > testes/transdutorRomanos/99_r.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutorRomanos/28_r.txt | fstarcsort > testes/transdutorRomanos/28_r.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutorRomanos/28_r.fst | dot -Tpdf  > testes/transdutorRomanos/28_r.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutorRomanos/100_r.txt | fstarcsort > testes/transdutorRomanos/100_r.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutorRomanos/100_r.fst | dot -Tpdf  > testes/transdutorRomanos/100_r.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutorRomanos/1_r.txt | fstarcsort > testes/transdutorRomanos/1_r.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutorRomanos/1_r.fst | dot -Tpdf  > testes/transdutorRomanos/1_r.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutorRomanos/8_r.txt | fstarcsort > testes/transdutorRomanos/8_r.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutorRomanos/8_r.fst | dot -Tpdf  > testes/transdutorRomanos/8_r.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutorRomanos/45_r.txt | fstarcsort > testes/transdutorRomanos/45_r.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutorRomanos/45_r.fst | dot -Tpdf  > testes/transdutorRomanos/45_r.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutorRomanos/72_r.txt | fstarcsort > testes/transdutorRomanos/72_r.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutorRomanos/72_r.fst | dot -Tpdf  > testes/transdutorRomanos/72_r.pdf

################   Testes do Transdutor 1 #####################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1/99_t1.txt | fstarcsort > testes/transdutor1/99_t1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1/99_t1.fst | dot -Tpdf  > testes/transdutor1/99_t1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1/99_aa_t1.txt | fstarcsort > testes/transdutor1/99_aa_t1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1/99_aa_t1.fst | dot -Tpdf  > testes/transdutor1/99_aa_t1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1/batata_28_t1.txt | fstarcsort > testes/transdutor1/batata_28_t1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1/batata_28_t1.fst | dot -Tpdf  > testes/transdutor1/batata_28_t1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1/ir_tambem_t1.txt | fstarcsort > testes/transdutor1/ir_tambem_t1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1/ir_tambem_t1.fst | dot -Tpdf  > testes/transdutor1/ir_tambem_t1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1/_ola_t1.txt | fstarcsort > testes/transdutor1/_ola_t1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1/_ola_t1.fst | dot -Tpdf  > testes/transdutor1/_ola_t1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1/batatada_com_alguem_21_t1.txt | fstarcsort > testes/transdutor1/batatada_com_alguem_21_t1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1/batatada_com_alguem_21_t1.fst | dot -Tpdf  > testes/transdutor1/batatada_com_alguem_21_t1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1/23_teste_35_vai_passar_t1.txt | fstarcsort > testes/transdutor1/23_teste_35_vai_passar_t1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1/23_teste_35_vai_passar_t1.fst | dot -Tpdf  > testes/transdutor1/23_teste_35_vai_passar_t1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1/13_sexta_feira_88_t1.txt | fstarcsort > testes/transdutor1/13_sexta_feira_88_t1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1/13_sexta_feira_88_t1.fst | dot -Tpdf  > testes/transdutor1/i13_sexta_feira_88_t1.pdf

################   Testes do Inverso do Transdutor 1   #######

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1Inv/XCIX__invt1.txt | fstarcsort > testes/transdutor1Inv/XCIX__invt1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1Inv/XCIX__invt1.fst | dot -Tpdf  > testes/transdutor1Inv/XCIX__invt1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1Inv/XCIX_aa_invt1.txt | fstarcsort > testes/transdutor1Inv/XCIX_aa_invt1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1Inv/XCIX_aa_invt1.fst | dot -Tpdf  > testes/transdutor1Inv/XCIX_aa_invt1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1Inv/batata_XXVIII_invt1.txt | fstarcsort > testes/transdutor1Inv/batata_XXVIII_invt1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1Inv/batata_XXVIII_invt1.fst | dot -Tpdf  > testes/transdutor1Inv/batata_XXVIII_invt1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1Inv/ir_tambem_invt1.txt | fstarcsort > testes/transdutor1Inv/ir_tambem_invt1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1Inv/ir_tambem_invt1.fst | dot -Tpdf  > testes/transdutor1Inv/ir_tambem_invt1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1Inv/_ola_invt1.txt | fstarcsort > testes/transdutor1Inv/_ola_invt1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1Inv/_ola_invt1.fst | dot -Tpdf  > testes/transdutor1Inv/_ola_invt1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1Inv/batatada_com_alguem_XXI_invt1.txt | fstarcsort > testes/transdutor1Inv/batatada_com_alguem_XXI_invt1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1Inv/batatada_com_alguem_XXI_invt1.fst | dot -Tpdf  > testes/transdutor1Inv/batatada_com_alguem_XXI_invt1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1Inv/XXIII_teste_XXXV_vai_passar_invt1.txt | fstarcsort > testes/transdutor1Inv/XXIII_teste_XXXV_vai_passar_invt1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1Inv/XXIII_teste_XXXV_vai_passar_invt1.fst | dot -Tpdf  > testes/transdutor1Inv/XXIII_teste_XXXV_vai_passar_invt1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor1Inv/XIII_sexta_feira_LXXXVIII_invt1.txt | fstarcsort > testes/transdutor1Inv/XIII_sexta_feira_LXXXVIII_invt1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor1Inv/XIII_sexta_feira_LXXXVIII_invt1.fst | dot -Tpdf  > testes/transdutor1Inv/XIII_sexta_feira_LXXXVIII_invt1.pdf

################   Testes do Transdutor 2 #####################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2/XCIX_t2.txt | fstarcsort > testes/transdutor2/XCIX_t2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2/XCIX_t2.fst | dot -Tpdf  > testes/transdutor2/XCIX_t2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2/XCIX_aa_t2.txt | fstarcsort > testes/transdutor2/XCIX_aa_t2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2/XCIX_aa_t2.fst | dot -Tpdf  > testes/transdutor2/XCIX_aa_t2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2/batata_XXVIII_t2.txt | fstarcsort > testes/transdutor2/batata_XXVIII_t2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2/batata_XXVIII_t2.fst | dot -Tpdf  > testes/transdutor2/batata_XXVIII_t2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2/ir_tambem_t2.txt | fstarcsort > testes/transdutor2/ir_tambem_t2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2/ir_tambem_t2.fst | dot -Tpdf  > testes/transdutor2/ir_tambem_t2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2/_ir_tambem_de_mota_t2.txt | fstarcsort > testes/transdutor2/_ir_tambem_de_mota_t2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2/_ir_tambem_de_mota_t2.fst | dot -Tpdf  > testes/transdutor2/_ir_tambem_de_mota_t2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2/ir_de_XL_mota_t2.txt | fstarcsort > testes/transdutor2/ir_de_XL_mota_t2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2/ir_de_XL_mota_t2.fst | dot -Tpdf  > testes/transdutor2/ir_de_XL_mota_t2.pdf

################   Testes do Inverso do Transdutor 2   #######

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2Inv/3513_invt2.txt | fstarcsort > testes/transdutor2Inv/3513_invt2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2Inv/3513_invt2.fst | dot -Tpdf  > testes/transdutor2Inv/3513_invt2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2Inv/3513_aa_invt2.txt | fstarcsort > testes/transdutor2Inv/3513_aa_invt2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2Inv/3513_aa_invt2.fst | dot -Tpdf  > testes/transdutor2Inv/3513_aa_invt2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2Inv/batata_332111_invt2.txt | fstarcsort > testes/transdutor2Inv/batata_332111_invt2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2Inv/batata_332111_invt2.fst | dot -Tpdf  > testes/transdutor2Inv/batata_332111_invt2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2Inv/ir_tambem_invt2.txt | fstarcsort > testes/transdutor2Inv/ir_tambem_invt2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2Inv/ir_tambem_invt2.fst | dot -Tpdf  > testes/transdutor2Inv/ir_tambem_invt2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2Inv/_ir_tambem_de_mota_invt2.txt | fstarcsort > testes/transdutor2Inv/_ir_tambem_de_mota_invt2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2Inv/_ir_tambem_de_mota_invt2.fst | dot -Tpdf  > testes/transdutor2Inv/_ir_tambem_de_mota_invt2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor2Inv/ir_de_34_mota_invt2.txt | fstarcsort > testes/transdutor2Inv/ir_de_34_mota_invt2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor2Inv/ir_de_34_mota_invt2.fst | dot -Tpdf  > testes/transdutor2Inv/ir_de_34_mota_invt2.pdf


################   Testes do Transdutor 3 #####################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor3/3513_t3.txt | fstarcsort > testes/transdutor3/3513_t3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor3/3513_t3.fst | dot -Tpdf  > testes/transdutor3/3513_t3.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor3/3513_aa_t3.txt | fstarcsort > testes/transdutor3/3513_aa_t3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor3/3513_aa_t3.fst | dot -Tpdf  > testes/transdutor3/3513_aa_t3.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor3/batata_332111_t3.txt | fstarcsort > testes/transdutor3/batata_332111_t3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor3/batata_332111_t3.fst | dot -Tpdf  > testes/transdutor3/batata_332111_t3.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor3/ir_tambem_t3.txt | fstarcsort > testes/transdutor3/ir_tambem_t3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor3/ir_tambem_t3.fst | dot -Tpdf  > testes/transdutor3/ir_tambem_t3.pdf

################   Testes do Inverso do Transdutor 3   #######

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor3Inv/3513_invt3.txt | fstarcsort > testes/transdutor3Inv/3513_invt3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor3Inv/3513_invt3.fst | dot -Tpdf  > testes/transdutor3Inv/3513_invt3.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor3Inv/3513_XX_invt3.txt | fstarcsort > testes/transdutor3Inv/3513_XX_invt3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor3Inv/3513_XX_invt3.fst | dot -Tpdf  > testes/transdutor3Inv/3513_XX_invt3.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor3Inv/bXtXtX_332111_invt3.txt | fstarcsort > testes/transdutor3Inv/bXtXtX_332111_invt3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor3Inv/bXtXtX_332111_invt3.fst | dot -Tpdf  > testes/transdutor3Inv/bXtXtX_332111_invt3.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/transdutor3Inv/Vr_tX79m_invt3.txt | fstarcsort > testes/transdutor3Inv/Vr_tX79m_invt3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/transdutor3Inv/Vr_tX79m_invt3.fst | dot -Tpdf  > testes/transdutor3Inv/Vr_tX79m_invt3.pdf

################   Testes do Codificador ######################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/codificador/99_c.txt | fstarcsort > testes/codificador/99_c.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/codificador/99_c.fst | dot -Tpdf  > testes/codificador/99_c.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/codificador/99_aa_c.txt | fstarcsort > testes/codificador/99_aa_c.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/codificador/99_aa_c.fst | dot -Tpdf  > testes/codificador/99_aa_c.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/codificador/batata_28_c.txt | fstarcsort > testes/codificador/batata_28_c.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/codificador/batata_28_c.fst | dot -Tpdf  > testes/codificador/batata_28_c.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/codificador/ir_tambem_c.txt | fstarcsort > testes/codificador/ir_tambem_c.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/codificador/ir_tambem_c.fst | dot -Tpdf  > testes/codificador/ir_tambem_c.pdf

################   Testes do Descodificador ###################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/descodificador/3513_d.txt | fstarcsort > testes/descodificador/3513_d.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/descodificador/3513_d.fst | dot -Tpdf  > testes/descodificador/3513_d.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/descodificador/3513_XX_d.txt | fstarcsort > testes/descodificador/3513_XX_d.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/descodificador/3513_XX_d.fst | dot -Tpdf  > testes/descodificador/3513_XX_d.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/descodificador/bXtXtX_332111_d.txt | fstarcsort > testes/descodificador/bXtXtX_332111_d.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/descodificador/bXtXtX_332111_d.fst | dot -Tpdf  > testes/descodificador/bXtXtX_332111_d.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  testes/descodificador/ir_tambem_d.txt | fstarcsort > testes/descodificador/ir_tambem_d.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait testes/descodificador/ir_tambem_d.fst | dot -Tpdf  > testes/descodificador/ir_tambem_d.pdf

############################################################################
################### Testa os Transdutores       ############################
############################################################################

################   Testes do Transdutor Romanos ###############

fstcompose testes/transdutorRomanos/99_r.fst transdutorRomanos.fst > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutorRomanos/Romanos_resultadoTeste1.fst | dot -Tpdf > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste1.pdf

fstcompose testes/transdutorRomanos/28_r.fst transdutorRomanos.fst > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutorRomanos/Romanos_resultadoTeste2.fst | dot -Tpdf > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste2.pdf

fstcompose testes/transdutorRomanos/100_r.fst transdutorRomanos.fst > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutorRomanos/Romanos_resultadoTeste3.fst | dot -Tpdf > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste3.pdf

fstcompose testes/transdutorRomanos/1_r.fst transdutorRomanos.fst > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste4.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutorRomanos/Romanos_resultadoTeste4.fst | dot -Tpdf > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste4.pdf

fstcompose testes/transdutorRomanos/8_r.fst transdutorRomanos.fst > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste5.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutorRomanos/Romanos_resultadoTeste5.fst | dot -Tpdf > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste5.pdf

fstcompose testes/transdutorRomanos/45_r.fst transdutorRomanos.fst > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste6.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutorRomanos/Romanos_resultadoTeste6.fst | dot -Tpdf > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste6.pdf

fstcompose testes/transdutorRomanos/72_r.fst transdutorRomanos.fst > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste7.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutorRomanos/Romanos_resultadoTeste7.fst | dot -Tpdf > resultadosTestes/transdutorRomanos/Romanos_resultadoTeste7.pdf

################   Testes do Transdutor 1 #####################

fstcompose testes/transdutor1/99_t1.fst transdutor1.fst > resultadosTestes/transdutor1/Transdutor1_resultadoTeste1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1/Transdutor1_resultadoTeste1.fst | dot -Tpdf > resultadosTestes/transdutor1/Transdutor1_resultadoTeste1.pdf

fstcompose testes/transdutor1/99_aa_t1.fst transdutor1.fst > resultadosTestes/transdutor1/Transdutor1_resultadoTeste2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1/Transdutor1_resultadoTeste2.fst | dot -Tpdf > resultadosTestes/transdutor1/Transdutor1_resultadoTeste2.pdf

fstcompose testes/transdutor1/batata_28_t1.fst transdutor1.fst > resultadosTestes/transdutor1/Transdutor1_resultadoTeste3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1/Transdutor1_resultadoTeste3.fst | dot -Tpdf > resultadosTestes/transdutor1/Transdutor1_resultadoTeste3.pdf

fstcompose testes/transdutor1/ir_tambem_t1.fst transdutor1.fst > resultadosTestes/transdutor1/Transdutor1_resultadoTeste4.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1/Transdutor1_resultadoTeste4.fst | dot -Tpdf > resultadosTestes/transdutor1/Transdutor1_resultadoTeste4.pdf

fstcompose testes/transdutor1/_ola_t1.fst transdutor1.fst > resultadosTestes/transdutor1/Transdutor1_resultadoTeste5.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1/Transdutor1_resultadoTeste5.fst | dot -Tpdf > resultadosTestes/transdutor1/Transdutor1_resultadoTeste5.pdf

fstcompose testes/transdutor1/batatada_com_alguem_21_t1.fst transdutor1.fst > resultadosTestes/transdutor1/Transdutor1_resultadoTeste6.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1/Transdutor1_resultadoTeste6.fst | dot -Tpdf > resultadosTestes/transdutor1/Transdutor1_resultadoTeste6.pdf

fstcompose testes/transdutor1/23_teste_35_vai_passar_t1.fst transdutor1.fst > resultadosTestes/transdutor1/Transdutor1_resultadoTeste7.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1/Transdutor1_resultadoTeste7.fst | dot -Tpdf > resultadosTestes/transdutor1/Transdutor1_resultadoTeste7.pdf

fstcompose testes/transdutor1/13_sexta_feira_88_t1.fst transdutor1.fst > resultadosTestes/transdutor1/Transdutor1_resultadoTeste8.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1/Transdutor1_resultadoTeste8.fst | dot -Tpdf > resultadosTestes/transdutor1/Transdutor1_resultadoTeste8.pdf

################   Testes do Inverso do Transdutor 1 ##########

fstcompose testes/transdutor1Inv/XCIX__invt1.fst transdutorInv1.fst > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste1.fst | dot -Tpdf > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste1.pdf

fstcompose testes/transdutor1Inv/XCIX_aa_invt1.fst transdutorInv1.fst > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste2.fst | dot -Tpdf > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste2.pdf

fstcompose testes/transdutor1Inv/batata_XXVIII_invt1.fst transdutorInv1.fst > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste3.fst | dot -Tpdf > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste3.pdf

fstcompose testes/transdutor1Inv/ir_tambem_invt1.fst transdutorInv1.fst > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste4.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste4.fst | dot -Tpdf > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste4.pdf

fstcompose testes/transdutor1Inv/_ola_invt1.fst transdutorInv1.fst > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste5.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste5.fst | dot -Tpdf > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste5.pdf

fstcompose testes/transdutor1Inv/batatada_com_alguem_XXI_invt1.fst transdutorInv1.fst > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste6.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste6.fst | dot -Tpdf > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste6.pdf

fstcompose testes/transdutor1Inv/XXIII_teste_XXXV_vai_passar_invt1.fst transdutorInv1.fst > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste7.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste7.fst | dot -Tpdf > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste7.pdf

fstcompose testes/transdutor1Inv/XIII_sexta_feira_LXXXVIII_invt1.fst transdutorInv1.fst > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste8.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste8.fst | dot -Tpdf > resultadosTestes/transdutor1Inv/InvTransdutor1_resultadoTeste8.pdf

################   Testes do Transdutor 2 #####################

fstcompose testes/transdutor2/XCIX_t2.fst transdutor2.fst > resultadosTestes/transdutor2/Transdutor2_resultadoTeste1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2/Transdutor2_resultadoTeste1.fst | dot -Tpdf > resultadosTestes/transdutor2/Transdutor2_resultadoTeste1.pdf

fstcompose testes/transdutor2/XCIX_aa_t2.fst transdutor2.fst > resultadosTestes/transdutor2/Transdutor2_resultadoTeste2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2/Transdutor2_resultadoTeste2.fst | dot -Tpdf > resultadosTestes/transdutor2/Transdutor2_resultadoTeste2.pdf

fstcompose testes/transdutor2/batata_XXVIII_t2.fst transdutor2.fst > resultadosTestes/transdutor2/Transdutor2_resultadoTeste3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2/Transdutor2_resultadoTeste3.fst | dot -Tpdf > resultadosTestes/transdutor2/Transdutor2_resultadoTeste3.pdf

fstcompose testes/transdutor2/ir_tambem_t2.fst transdutor2.fst > resultadosTestes/transdutor2/Transdutor2_resultadoTeste4.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2/Transdutor2_resultadoTeste4.fst | dot -Tpdf > resultadosTestes/transdutor2/Transdutor2_resultadoTeste4.pdf

fstcompose testes/transdutor2/_ir_tambem_de_mota_t2.fst transdutor2.fst > resultadosTestes/transdutor2/Transdutor2_resultadoTeste5.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2/Transdutor2_resultadoTeste5.fst | dot -Tpdf > resultadosTestes/transdutor2/Transdutor2_resultadoTeste5.pdf

fstcompose testes/transdutor2/ir_de_XL_mota_t2.fst transdutor2.fst > resultadosTestes/transdutor2/Transdutor2_resultadoTeste6.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2/Transdutor2_resultadoTeste6.fst | dot -Tpdf > resultadosTestes/transdutor2/Transdutor2_resultadoTeste6.pdf

################   Testes do Inverso do Transdutor 2 ##########

fstcompose testes/transdutor2Inv/3513_invt2.fst transdutorInv2.fst > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste1.fst | dot -Tpdf > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste1.pdf

fstcompose testes/transdutor2Inv/3513_aa_invt2.fst transdutorInv2.fst > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste2.fst | dot -Tpdf > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste2.pdf

fstcompose testes/transdutor2Inv/batata_332111_invt2.fst transdutorInv2.fst > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste3.fst | dot -Tpdf > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste3.pdf

fstcompose testes/transdutor2Inv/ir_tambem_invt2.fst transdutorInv2.fst > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste4.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste4.fst | dot -Tpdf > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste4.pdf

fstcompose testes/transdutor2Inv/_ir_tambem_de_mota_invt2.fst transdutorInv2.fst > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste5.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste5.fst | dot -Tpdf > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste5.pdf

fstcompose testes/transdutor2Inv/ir_de_34_mota_invt2.fst transdutorInv2.fst > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste6.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste6.fst | dot -Tpdf > resultadosTestes/transdutor2Inv/InvTransdutor2_resultadoTeste6.pdf

################   Testes do Transdutor 3 #####################

fstcompose testes/transdutor3/3513_t3.fst transdutor3.fst > resultadosTestes/transdutor3/Transdutor3_resultadoTeste1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor3/Transdutor3_resultadoTeste1.fst | dot -Tpdf > resultadosTestes/transdutor3/Transdutor3_resultadoTeste1.pdf

fstcompose testes/transdutor3/3513_aa_t3.fst transdutor3.fst > resultadosTestes/transdutor3/Transdutor3_resultadoTeste2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor3/Transdutor3_resultadoTeste2.fst | dot -Tpdf > resultadosTestes/transdutor3/Transdutor3_resultadoTeste2.pdf

fstcompose testes/transdutor3/batata_332111_t3.fst transdutor3.fst > resultadosTestes/transdutor3/Transdutor3_resultadoTeste3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor3/Transdutor3_resultadoTeste3.fst | dot -Tpdf > resultadosTestes/transdutor3/Transdutor3_resultadoTeste3.pdf

fstcompose testes/transdutor3/ir_tambem_t3.fst transdutor3.fst > resultadosTestes/transdutor3/Transdutor3_resultadoTeste4.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor3/Transdutor3_resultadoTeste4.fst | dot -Tpdf > resultadosTestes/transdutor3/Transdutor3_resultadoTeste4.pdf

################   Testes do Inverso do Transdutor 3 ##########

fstcompose testes/transdutor3Inv/3513_invt3.fst transdutorInv3.fst > resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste1.fst | dot -Tpdf > resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste1.pdf

fstcompose testes/transdutor3Inv/3513_XX_invt3.fst transdutorInv3.fst > resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste2.fst | dot -Tpdf > resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste2.pdf

fstcompose testes/transdutor3Inv/bXtXtX_332111_invt3.fst transdutorInv3.fst > resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste3.fst | dot -Tpdf > resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste3.pdf

fstcompose testes/transdutor3Inv/Vr_tX79m_invt3.fst transdutorInv3.fst > resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste4.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste4.fst | dot -Tpdf > resultadosTestes/transdutor3Inv/InvTransdutor3_resultadoTeste4.pdf

################   Testes do Codificador ######################

fstcompose testes/codificador/99_c.fst codificador.fst > resultadosTestes/codificador/Codificador_resultadoTeste1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/codificador/Codificador_resultadoTeste1.fst | dot -Tpdf > resultadosTestes/codificador/Codificador_resultadoTeste1.pdf

fstcompose testes/codificador/99_aa_c.fst codificador.fst > resultadosTestes/codificador/Codificador_resultadoTeste2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/codificador/Codificador_resultadoTeste2.fst | dot -Tpdf > resultadosTestes/codificador/Codificador_resultadoTeste2.pdf

fstcompose testes/codificador/batata_28_c.fst codificador.fst > resultadosTestes/codificador/Codificador_resultadoTeste3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/codificador/Codificador_resultadoTeste3.fst | dot -Tpdf > resultadosTestes/codificador/Codificador_resultadoTeste3.pdf

fstcompose testes/codificador/ir_tambem_c.fst codificador.fst > resultadosTestes/codificador/Codificador_resultadoTeste4.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/codificador/Codificador_resultadoTeste4.fst | dot -Tpdf > resultadosTestes/codificador/Codificador_resultadoTeste4.pdf

################   Testes do Descodificador ###################

fstcompose testes/descodificador/3513_d.fst descodificador.fst > resultadosTestes/descodificador/Descodificador_resultadoTeste1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/descodificador/Descodificador_resultadoTeste1.fst | dot -Tpdf > resultadosTestes/descodificador/Descodificador_resultadoTeste1.pdf

fstcompose testes/descodificador/3513_XX_d.fst descodificador.fst > resultadosTestes/descodificador/Descodificador_resultadoTeste2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/descodificador/Descodificador_resultadoTeste2.fst | dot -Tpdf > resultadosTestes/descodificador/Descodificador_resultadoTeste2.pdf

fstcompose testes/descodificador/bXtXtX_332111_d.fst descodificador.fst > resultadosTestes/descodificador/Descodificador_resultadoTeste3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/descodificador/Descodificador_resultadoTeste3.fst | dot -Tpdf > resultadosTestes/descodificador/Descodificador_resultadoTeste3.pdf

fstcompose testes/descodificador/ir_tambem_d.fst descodificador.fst > resultadosTestes/descodificador/Descodificador_resultadoTeste4.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosTestes/descodificador/Descodificador_resultadoTeste4.fst | dot -Tpdf > resultadosTestes/descodificador/Descodificador_resultadoTeste4.pdf

############################################################################
###################    Descodifica Emails        ###########################
############################################################################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  emails/descodificar1.txt | fstarcsort > emails/descodificar1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait emails/descodificar1.fst | dot -Tpdf  > emails/descodificar1.pdf

fstcompose emails/descodificar1.fst descodificador.fst > resultadosEmails/Descodifica1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosEmails/Descodifica1.fst | dot -Tpdf > resultadosEmails/Descodifica1.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  emails/descodificar2.txt | fstarcsort > emails/descodificar2.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait emails/descodificar2.fst | dot -Tpdf  > emails/descodificar2.pdf

fstcompile --isymbols=syms.txt --osymbols=syms.txt  emails/descodificar3.txt | fstarcsort > emails/descodificar3.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait emails/descodificar3.fst | dot -Tpdf  > emails/descodificar3.pdf

fstcompose emails/descodificar2.fst descodificador.fst > resultadosEmails/Descodifica2.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosEmails/Descodifica2.fst | dot -Tpdf > resultadosEmails/Descodifica2.pdf

fstcompose emails/descodificar3.fst descodificador.fst > resultadosEmails/Descodifica3.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosEmails/Descodifica3.fst | dot -Tpdf > resultadosEmails/Descodifica3.pdf

############################################################################
###################    Codifica Emails        ##############################
############################################################################

fstcompile --isymbols=syms.txt --osymbols=syms.txt  emails/codificar1.txt | fstarcsort > emails/codificar1.fst
fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait emails/codificar1.fst | dot -Tpdf  > emails/codificar1.pdf

fstcompose emails/codificar1.fst codificador.fst > resultadosEmails/Codifica1.fst
fstdraw --isymbols=syms.txt --osymbols=syms.txt --portrait resultadosEmails/Codifica1.fst | dot -Tpdf > resultadosEmails/Codifica1.pdf
