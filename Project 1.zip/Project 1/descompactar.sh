python scripts/compact2fst.py compactos/transdutorIgnoraLetrasCompacto.txt > transdutorIgnoraLetras.txt
python scripts/compact2fst.py compactos/transdutor2Compacto.txt > transdutor2.txt
python scripts/compact2fst.py compactos/transdutor3Compacto.txt > transdutor3.txt